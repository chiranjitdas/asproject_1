const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const passport = require('passport');
const helmet = require('helmet')
const cors = require('cors')
const config = require('./conf/db');

const routes = require('./routes'); 

mongoose.connect(config.DB, { useNewUrlParser: true }).then(
    () => {console.log('Database is connected') },
    err => { console.log('Can not connect to the database'+ err)}
);

const app = express();
app.use(helmet())
const router = express.Router()
routes(router)

app.use(passport.initialize());
require('./passport')(passport);
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

//app.use('/api/users', users);
app.use('/api', router)
app.get('/', function(req, res) {
    res.send('Welcome to Precision Pan');
});

const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
    console.log(`Server is running on PORT ${PORT}`);
});