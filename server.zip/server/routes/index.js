const users = require('./main/user')

module.exports = (router) => {
    users(router)
}