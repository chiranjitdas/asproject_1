// server/routes/products.js
const userscontroller = require('../../controllers/main/user.ctrl')
const multipart = require('connect-multiparty')
const multipartWare = multipart()

module.exports = (router) => {

    /**
     * get all articles
     */
    router
        .route('/users/register')
        .post(userscontroller.register)
     
    router
        .route('/users/login')
        .post(userscontroller.login)
     
    router
        .route('/users/me')
        .get(userscontroller.me)

    /**
     * add an article
     
    router
        .route('/article')
        .post(multipartWare, productscontroller.addArticle)

    /**
     * clap on an article
    */
    /*router
        .route('/product/likeproduct')
        .post(multipartWare, productscontroller.likeProduct)
*/
    /**
     * comment on an article
   
    router
        .route('/article/comment')
        .post(productscontroller.commentArticle)

    /**
     * get a particlular article to view

    router
        .route('/article/:id')
        .get(productscontroller.getArticle)
        */
}